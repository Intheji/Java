package day0921;

public class Car {
	String color = "white";
	int door = 4;
	
	Car() {}
	
	void drive() {
		System.out.println("drive~~");
	}
	
	void stop() {
		System.out.println("stop!!!");
	}
}

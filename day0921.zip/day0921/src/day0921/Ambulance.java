package day0921;

public class Ambulance extends Car {
	void siren() {
		System.out.println("으아아아아아악");
	}
}

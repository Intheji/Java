package day0921;

public class FireEngine extends Car {
	
	void water() {
		System.out.println("water~~");
	}
}

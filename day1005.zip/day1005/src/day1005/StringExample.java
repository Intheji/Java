package day1005;


public class StringExample {
	public static void main(String[] args) {
		
		String[] words = {"java", "database", "spring", "springboot", "jsp"};
		
		
		System.out.println("현재의 상태 : ______");
		System.out.printf("글자를 추측하시오 : ");
		
	
		
	}
}
